﻿using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Restaurant_Aid.Controls;
using Restaurant_Aid.Views;
using Restaurant_Aid.Model;

namespace Restaurant_Aid.ViewModels
{
	public class CustomerSearchPageViewModel : BindableBase
	{
        public CustomerSearchPageViewModel()
        {

        }
	}
}
