﻿using Prism.Commands;
using Prism.Mvvm;
using Restaurant_Aid.Model;
using Restaurant_Aid.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Restaurant_Aid.ViewModels
{
	public class OrderInfoPageViewModel : BindableBase
	{
        public OrderInfoPageViewModel()
        {

        }
	}
}
