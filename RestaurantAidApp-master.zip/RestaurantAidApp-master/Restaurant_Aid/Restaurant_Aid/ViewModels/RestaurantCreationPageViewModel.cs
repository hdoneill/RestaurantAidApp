﻿using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Restaurant_Aid.ViewModels
{
	public class RestaurantCreationPageViewModel : BindableBase
	{
        public RestaurantCreationPageViewModel()
        {

        }
	}
}
