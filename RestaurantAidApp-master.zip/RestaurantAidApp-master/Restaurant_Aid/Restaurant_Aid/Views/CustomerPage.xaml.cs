﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Restaurant_Aid.Views
{
    public partial class CustomerPage : ContentPage
    {
        public CustomerPage()
        {
            InitializeComponent();
        }
    }
}
